CODING CONVENTIONS AND RULES TO FOLLOW ACCORDING TO THE INSTRUCTOR'S MANUAL TOO:

https://www.canva.com/design/DAFbY5leaVw/IS51sjpC8Bs5AcVGJM0pBA/edit?utm_content=DAFbY5leaVw&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton
