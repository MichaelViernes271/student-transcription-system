import os, time

def newStudentFeature():
	"""Calls another student to view their profiles in transcription system.
	Breaks the looping of the current student and goes to another student."""
	input("Signing out. Calling new student...")
	clearConsole()

def clearConsole():
        """Clear screen."""
        time.sleep(1)
        os.system("cls")  # for windows_os == "clear", else for unix == "cls"
        # call("cls" if os.name == "nt" else "clear") # this sometimes not work